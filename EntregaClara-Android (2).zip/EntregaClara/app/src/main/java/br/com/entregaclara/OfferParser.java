package br.com.entregaclara;

import java.util.*;
import java.util.regex.*;

/** Conservative generic adapter. Ambiguous screens produce no offer. */
public final class OfferParser {
    private static final Pattern MONEY = Pattern.compile("R\\$\\s*(\\d{1,4}(?:[.,]\\d{2})?)(?![\\d.,])", Pattern.CASE_INSENSITIVE);
    private static final Pattern KM = Pattern.compile("(?<![\\d.,])(\\d{1,3}(?:[.,]\\d{1,2})?)\\s*km\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern ACTION = Pattern.compile("\\b(aceitar|aceite|nova entrega|novo pedido|oferta de entrega)\\b", Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
    private static final Pattern TIME = Pattern.compile("(?<![\\d.,])(\\d{1,3})\\s*min(?:utos)?\\b", Pattern.CASE_INSENSITIVE);
    public static final class Offer {
        public final double amount, km;
        public final Integer minutes;
        public Offer(double amount, double km, Integer minutes) { this.amount=amount; this.km=km; this.minutes=minutes; }
        public double perKm() { return amount/km; }
        public double net(double cost) { return amount-km*cost; }
    }
    public static Offer parse(String text) {
        if (text == null || !ACTION.matcher(text).find()) return null;
        List<Double> money=values(MONEY,text), distance=values(KM,text);
        // Multiple distances may be pickup + delivery or repeated totals. Never guess.
        if(money.size()!=1 || distance.size()!=1) return null;
        double amount=money.get(0), km=distance.get(0);
        if(amount<=0 || km<=0 || amount>10000 || km>300) return null;
        Matcher m=TIME.matcher(text); Integer minutes=null;
        if(m.find()) { int n=Integer.parseInt(m.group(1)); if(n>0 && !m.find()) minutes=n; }
        return new Offer(amount,km,minutes);
    }
    private static List<Double> values(Pattern p,String text) {
        List<Double> result=new ArrayList<>(); Matcher m=p.matcher(text);
        while(m.find()) { try { result.add(Double.parseDouble(m.group(1).replace(',','.'))); } catch(NumberFormatException ignored) {} }
        return result;
    }
}
