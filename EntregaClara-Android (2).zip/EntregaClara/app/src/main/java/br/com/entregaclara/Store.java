package br.com.entregaclara;

import android.content.*;
import org.json.*;
import java.text.*;
import java.util.*;

final class Store {
    static android.content.SharedPreferences prefs(Context c) { return c.getSharedPreferences("entrega",0); }
    static double number(Context c,String key,double def) { return prefs(c).getFloat(key,(float)def); }
    static Set<String> packages(Context c) { return new HashSet<>(prefs(c).getStringSet("packages",Collections.emptySet())); }
    static String cash(double n) { return NumberFormat.getCurrencyInstance(new Locale("pt","BR")).format(n); }
    static String decimal(double n) { return String.format(new Locale("pt","BR"),"%.2f",n); }
    static String day(long t) { return new SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).format(new Date(t)); }
    static JSONArray list(Context c,String key) { try { return new JSONArray(prefs(c).getString(key,"[]")); } catch(JSONException e) { return new JSONArray(); } }
    static void add(Context c,String key,String platform,OfferParser.Offer offer) {
        try {
            JSONObject item=new JSONObject(); item.put("time",System.currentTimeMillis()); item.put("platform",platform);
            item.put("amount",offer.amount); item.put("km",offer.km); item.put("cost",number(c,"cost",0.35));
            JSONArray list=list(c,key), out=new JSONArray(); out.put(item);
            for(int i=0;i<Math.min(list.length(),199);i++) out.put(list.get(i));
            prefs(c).edit().putString(key,out.toString()).apply();
        } catch(JSONException ignored) {}
    }
    static double today(Context c) {
        JSONArray list=list(c,"completed"); double value=0;
        for(int i=0;i<list.length();i++) { JSONObject x=list.optJSONObject(i); if(x!=null && day(x.optLong("time")).equals(day(System.currentTimeMillis()))) value+=x.optDouble("amount",0); }
        return value;
    }
}
