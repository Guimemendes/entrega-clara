package br.com.entregaclara;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout body;
    private final int ink=Color.rgb(231,240,247), muted=Color.rgb(155,176,195);
    @Override public void onCreate(Bundle state) { super.onCreate(state); render(); }
    @Override public void onResume() { super.onResume(); render(); }
    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }
    private void render() {
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(10,19,29));
        body=new LinearLayout(this); body.setOrientation(1); body.setPadding(dp(22),dp(32),dp(22),dp(32)); scroll.addView(body); setContentView(scroll);
        text("ENTREGA CLARA",14,Color.rgb(63,218,173)); text("Cada entrega, uma decisão.",28,ink);
        text("100% gratuito • sem anúncios ou assinatura",13,muted);
        text("Android • versão experimental 0.1",13,muted);
        card("Seu dia",Store.cash(Store.today(this))+" registrados hoje\nMeta: "+Store.cash(Store.number(this,"goal",150))+"\nFaltam "+Store.cash(Math.max(0,Store.number(this,"goal",150)-Store.today(this)))+" para a meta.");
        text("Somente entregas confirmadas manualmente entram na meta. Valores brutos; custos são estimativas.",13,muted);
        boolean consent=Store.prefs(this).getBoolean("consent",false);
        Switch active=new Switch(this); active.setText("Análise automática"); active.setTextColor(ink); active.setChecked(Store.prefs(this).getBoolean("active",false)); body.addView(active);
        active.setOnCheckedChangeListener((v,on)->{
            if(on && !consent) { active.setChecked(false); disclose(); return; }
            if(on && Store.packages(this).isEmpty()) { active.setChecked(false); new AlertDialog.Builder(this).setMessage("Selecione os aplicativos de entregador antes de ligar.").setPositiveButton("Selecionar",(d,w)->chooseApps()).show(); return; }
            Store.prefs(this).edit().putBoolean("active",on).apply();
        });
        String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        String component=new ComponentName(this,OfferService.class).flattenToString();
        text(enabled!=null && Arrays.asList(enabled.split(":")).contains(component) ? "Serviço de acessibilidade habilitado" : "Serviço de acessibilidade ainda não habilitado",13,muted);
        text(Store.packages(this).size()+" aplicativo(s) selecionado(s). Compatibilidade em validação.",13,muted);
        button("1. Entender e permitir a leitura",this::disclose);
        button("2. Escolher Keeta, 99Food e iFood",this::chooseApps);
        button("3. Abrir acessibilidade do Android",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        button("Calcular uma oferta / registrar entrega",this::manual);
        button("Meus limites, veículo e meta",this::settings);
        button("Histórico de ofertas analisadas",()->history("analyzed"));
        button("Entregas confirmadas",()->history("completed"));
        button("Testar cálculo com oferta fictícia",()->showOffer(new OfferParser.Offer(12,4,20),"Demonstração",false));
        button("Privacidade e apagar dados",this::privacy);
        text("Nenhuma oferta é aceita automaticamente. Se valor ou distância não forem claros, confira no aplicativo de entrega. Sem leitura de imagem/OCR nesta versão.",13,muted);
    }
    private void text(String value,int size,int color) { TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,dp(7),0,dp(7));body.addView(v); }
    private void card(String title,String value) {
        TextView v=new TextView(this);v.setText(title+"\n\n"+value);v.setTextSize(20);v.setTextColor(ink);v.setPadding(dp(18),dp(18),dp(18),dp(18));
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(22,39,53));bg.setCornerRadius(dp(18));v.setBackground(bg);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(18),0,dp(8));body.addView(v,lp);
    }
    private void button(String title,Runnable action) { Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setOnClickListener(v->action.run());body.addView(b,new LinearLayout.LayoutParams(-1,-2)); }
    private void disclose() {
        new AlertDialog.Builder(this).setTitle("Permitir análise das telas?")
            .setMessage("Ao habilitar o serviço de acessibilidade, o Android permite acesso ao conteúdo das telas. O Entrega Clara só consulta textos quando o aplicativo em primeiro plano está na sua lista selecionada, para localizar preço, distância e tempo da oferta.\n\nO cartão aparece sobre a tela usando o próprio serviço de acessibilidade. Não executamos toques, gestos ou aceites. Não há conexão de internet, coleta de endereços ou gravação de telas. Guardamos localmente apenas aplicativo, data, valor, km e custo estimado.\n\nA leitura é experimental e pode falhar. Pause na tela inicial ou desative o serviço a qualquer momento.")
            .setNegativeButton("Agora não",null).setPositiveButton("Concordo",(d,w)->{ Store.prefs(this).edit().putBoolean("consent",true).apply();render(); }).show();
    }
    private void chooseApps() {
        Intent launcher=new Intent(Intent.ACTION_MAIN);launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all=getPackageManager().queryIntentActivities(launcher,0);
        TreeMap<String,String> apps=new TreeMap<>();
        for(ResolveInfo r:all) { String p=r.activityInfo.packageName; if(!p.equals(getPackageName())) apps.put(r.loadLabel(getPackageManager())+"\n"+p,p); }
        String[] labels=apps.keySet().toArray(new String[0]), packages=apps.values().toArray(new String[0]);
        Set<String> chosen=Store.packages(this);boolean[] checked=new boolean[labels.length]; for(int i=0;i<labels.length;i++) checked[i]=chosen.contains(packages[i]);
        new AlertDialog.Builder(this).setTitle("Marque só os apps de entregador")
            .setMultiChoiceItems(labels,checked,(d,i,on)->checked[i]=on)
            .setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{ Set<String> result=new HashSet<>();for(int i=0;i<checked.length;i++) if(checked[i]) result.add(packages[i]); Store.prefs(this).edit().putStringSet("packages",result).apply();render(); }).show();
    }
    private LinearLayout form() { LinearLayout v=new LinearLayout(this);v.setOrientation(1);v.setPadding(dp(20),dp(8),dp(20),dp(8));return v; }
    private EditText field(LinearLayout parent,String label,String value) { TextView t=new TextView(this);t.setText(label);parent.addView(t); EditText e=new EditText(this);e.setText(value);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);parent.addView(e);return e; }
    private double number(EditText e) { double v=Double.parseDouble(e.getText().toString().trim().replace(',','.')); if(!Double.isFinite(v)||v<0) throw new IllegalArgumentException(); return v; }
    private void settings() {
        LinearLayout f=form();Spinner vehicle=new Spinner(this);String[] vehicles={"Moto","Bicicleta","Carro","Bicicleta elétrica"};vehicle.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,vehicles));vehicle.setSelection(Store.prefs(this).getInt("vehicle",0));f.addView(vehicle);
        EditText cost=field(f,"Custo total estimado por km (R$)",Store.decimal(Store.number(this,"cost",0.35)));
        EditText low=field(f,"Amarelo a partir de (R$/km)",Store.decimal(Store.number(this,"low",1.5)));
        EditText good=field(f,"Verde a partir de (R$/km)",Store.decimal(Store.number(this,"good",2)));
        EditText goal=field(f,"Meta diária bruta (R$)",Store.decimal(Store.number(this,"goal",150)));
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Seus critérios").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{try {double c=number(cost),l=number(low),g=number(good),m=number(goal);if(g<=l||m<=0)throw new IllegalArgumentException();Store.prefs(this).edit().putFloat("cost",(float)c).putFloat("low",(float)l).putFloat("good",(float)g).putFloat("goal",(float)m).putInt("vehicle",vehicle.getSelectedItemPosition()).apply();d.dismiss();render();}catch(Exception e){Toast.makeText(this,"Revise os valores: verde deve superar amarelo e meta deve ser positiva.",Toast.LENGTH_LONG).show();}}));d.show();
    }
    private void manual() {
        LinearLayout f=form();Spinner platform=new Spinner(this);platform.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Keeta","99Food","iFood"}));f.addView(platform);
        EditText value=field(f,"Valor da entrega (R$)",""),km=field(f,"Distância total, incluindo coleta (km)",""),time=field(f,"Minutos totais (opcional)","");
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Avaliar oferta").setView(f).setNegativeButton("Cancelar",null).setPositiveButton("Calcular",null).create();
        d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{try{double a=number(value),k=number(km);Integer t=time.getText().toString().trim().isEmpty()?null:(int)number(time);if(a<=0||k<=0||(t!=null&&t<=0))throw new IllegalArgumentException();OfferParser.Offer o=new OfferParser.Offer(a,k,t);String p=platform.getSelectedItem().toString();Store.add(this,"analyzed",p,o);d.dismiss();showOffer(o,p,true);}catch(Exception e){Toast.makeText(this,"Preencha valor e km positivos; tempo é opcional.",Toast.LENGTH_LONG).show();}}));d.show();
    }
    private void showOffer(OfferParser.Offer o,String platform,boolean save) {
        double rate=o.perKm();String status=rate>=Store.number(this,"good",2)?"VERDE":rate>=Store.number(this,"low",1.5)?"AMARELO":"VERMELHO";
        String msg=status+" • "+Store.cash(rate)+"/km\nValor: "+Store.cash(o.amount)+"\nDistância: "+Store.decimal(o.km)+" km\nLíquido estimado: "+Store.cash(o.net(Store.number(this,"cost",0.35)))+(o.minutes==null?"":"\nBruto por hora estimado: "+Store.cash(o.amount*60/o.minutes))+"\n\nO custo por km é uma estimativa configurável. Confira a distância total no app.";
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(platform).setMessage(msg).setNegativeButton("Fechar",null);
        if(save)b.setPositiveButton("Registrar como concluída",(d,w)->new AlertDialog.Builder(this).setTitle("Entrega concluída?").setMessage("Confirme somente se você realizou esta entrega. Isso acrescenta "+Store.cash(o.amount)+" aos ganhos brutos de hoje.").setNegativeButton("Voltar",null).setPositiveButton("Confirmar",(a,z)->{Store.add(this,"completed",platform,o);render();}).show());b.show();
    }
    private void history(String key) {
        JSONArray list=Store.list(this,key);StringBuilder s=new StringBuilder();SimpleDateFormat date=new SimpleDateFormat("dd/MM HH:mm",new Locale("pt","BR"));
        for(int i=0;i<list.length();i++){JSONObject x=list.optJSONObject(i);if(x==null)continue;s.append(date.format(new Date(x.optLong("time")))).append(" • ").append(x.optString("platform")).append("\n").append(Store.cash(x.optDouble("amount"))).append(" • ").append(Store.decimal(x.optDouble("km"))).append(" km\n\n");}
        new AlertDialog.Builder(this).setTitle(key.equals("completed")?"Entregas confirmadas":"Ofertas analisadas ≠ ganhos").setMessage(s.length()==0?"Nenhum registro ainda.":s.toString()).setPositiveButton("Fechar",null).show();
    }
    private void privacy() {
        new AlertDialog.Builder(this).setTitle("Seus dados ficam no aparelho").setMessage("Sem conta e sem internet. Máximo de 200 registros por histórico. As estimativas usam seus critérios; não há vínculo com Keeta, 99Food ou iFood.\n\nApagar remove históricos, seleção de apps, consentimento e configurações, e pausa a análise. Você também pode desativar o serviço na acessibilidade do Android.")
            .setNegativeButton("Fechar",null).setPositiveButton("Apagar todos os dados",(d,w)->new AlertDialog.Builder(this).setMessage("Apagar permanentemente os dados locais?").setNegativeButton("Cancelar",null).setPositiveButton("Apagar",(a,b)->{Store.prefs(this).edit().clear().apply();render();}).show()).show();
    }
}
