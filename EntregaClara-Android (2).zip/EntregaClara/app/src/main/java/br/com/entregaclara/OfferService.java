package br.com.entregaclara;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;

public class OfferService extends AccessibilityService implements SharedPreferences.OnSharedPreferenceChangeListener {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView overlay; private WindowManager wm;
    private String last="";private long lastTime;
    private final Runnable expire=()->hide();
    private final Runnable read=()->scan();
    @Override protected void onServiceConnected() { wm=(WindowManager)getSystemService(WINDOW_SERVICE); Store.prefs(this).registerOnSharedPreferenceChangeListener(this); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if(e.getPackageName()==null)return;
        String p=e.getPackageName().toString();
        if(p.equals(getPackageName()))return;
        if(!allowed(p)){handler.removeCallbacks(read);hide();return;}
        handler.removeCallbacks(read);handler.postDelayed(read,450);
    }
    private boolean allowed(String p) { return Store.prefs(this).getBoolean("consent",false) && Store.prefs(this).getBoolean("active",false) && Store.packages(this).contains(p); }
    private void scan() {
        AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null){hide();return;}
        try {
            String p=root.getPackageName()==null?"":root.getPackageName().toString(); if(!allowed(p)){hide();return;}
            StringBuilder text=new StringBuilder();collect(root,text,0,new int[]{0});
            OfferParser.Offer offer=OfferParser.parse(text.toString());if(offer==null){hide();return;}
            String label=p;try{label=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(p,0)).toString();}catch(Exception ignored){}
            String signature=p+":"+offer.amount+":"+offer.km;
            if(!signature.equals(last)||SystemClock.elapsedRealtime()-lastTime>60000){Store.add(this,"analyzed",label,offer);last=signature;lastTime=SystemClock.elapsedRealtime();}
            show(label,offer);
        } finally {root.recycle();}
    }
    private void collect(AccessibilityNodeInfo node,StringBuilder text,int depth,int[] count) {
        if(depth>35||++count[0]>500||text.length()>16000)return;
        if(node.isVisibleToUser() && node.getText()!=null)text.append(node.getText()).append('\n');
        for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child!=null){try{collect(child,text,depth+1,count);}finally{child.recycle();}}}
    }
    private void show(String label,OfferParser.Offer o) {
        hide(); if(wm==null)return;
        double low=Store.number(this,"low",1.5),good=Store.number(this,"good",2),rate=o.perKm();
        String tag=rate>=good?"VERDE":rate>=low?"AMARELO":"VERMELHO";
        int color=rate>=good?Color.rgb(15,100,75):rate>=low?Color.rgb(119,80,8):Color.rgb(141,39,49);
        overlay=new TextView(this);overlay.setTextColor(Color.WHITE);overlay.setTextSize(15);overlay.setPadding(22,16,22,16);
        overlay.setText("EXPERIMENTAL • "+label+"\n"+tag+"  "+Store.cash(rate)+"/km\n"+Store.cash(o.amount)+" • "+Store.decimal(o.km)+" km\nLíquido estimado: "+Store.cash(o.net(Store.number(this,"cost",0.35)))+"\nConfira coleta + entrega no app\nToque para fechar");
        GradientDrawable bg=new GradientDrawable();bg.setColor(color);bg.setCornerRadius(24);overlay.setBackground(bg);overlay.setOnClickListener(v->hide());
        WindowManager.LayoutParams lp=new WindowManager.LayoutParams(Math.round(280*getResources().getDisplayMetrics().density),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.END;lp.y=Math.round(72*getResources().getDisplayMetrics().density);
        try{wm.addView(overlay,lp);handler.postDelayed(expire,10000);}catch(RuntimeException e){overlay=null;}
    }
    private void hide(){handler.removeCallbacks(expire);if(overlay!=null){try{if(wm!=null)wm.removeView(overlay);}catch(RuntimeException ignored){}overlay=null;}}
    @Override public void onSharedPreferenceChanged(SharedPreferences p,String key){if(!p.getBoolean("active",false)||!p.getBoolean("consent",false)||"packages".equals(key)){handler.removeCallbacks(read);hide();}}
    @Override public void onInterrupt(){handler.removeCallbacks(read);hide();}
    @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);hide();Store.prefs(this).unregisterOnSharedPreferenceChangeListener(this);super.onDestroy();}
}
