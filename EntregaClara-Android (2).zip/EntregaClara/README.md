# Entrega Clara — Android 0.1 experimental

Projeto Android nativo em Java, com identidade própria, para auxiliar na avaliação de entregas. Não é afiliado ao Rota Pro, Keeta, 99Food ou iFood.

## Totalmente gratuito

Este projeto é gratuito: sem assinatura, anúncios, compras internas, período de teste, cobrança por entrega ou recursos bloqueados por pagamento. Não exige conta ou servidor pago para usar as funções implementadas. O código é disponibilizado sob licença MIT, incluída em `LICENSE`, permitindo uso, modificação e distribuição sem taxa de licença.

As funções deste app não alteram taxas ou condições cobradas pelas plataformas de entrega. Uma eventual publicação em loja pode envolver custos da própria loja para quem publica; não há cobrança ao usuário implementada neste aplicativo.

## Estado da entrega

Este pacote contém **código-fonte, não um APK instalável**. O app completo não foi compilado nem executado em emulador/celular neste ambiente, que não possui Android SDK ou Gradle. O parser e as fórmulas têm verificações executáveis independentes de Android. Não existe compatibilidade validada com as telas atuais dos três aplicativos.

## Recursos implementados no código

- Calculadora manual de valor por km, valor bruto por hora quando há duração e líquido estimado por custo total por km.
- Critérios de cores configuráveis; exemplos iniciais de R$ 1,50/km e R$ 2,00/km não são recomendações financeiras.
- Veículo selecionável (moto como padrão). A seleção é apenas um perfil descritivo: ajuste manualmente o custo total por km de acordo com seu veículo, incluindo energia/combustível, manutenção e outros custos relevantes.
- Meta diária bruta baseada apenas em entregas confirmadas manualmente.
- Histórico de ofertas analisadas separado do histórico de entregas concluídas. Máximo de 200 registros por histórico; não é um livro financeiro permanente.
- Leitura experimental de textos acessíveis e cartão temporário sobre a tela, usando `TYPE_ACCESSIBILITY_OVERLAY`.
- Consentimento explícito, seleção de aplicativos instalados, pausa e exclusão dos dados locais.

## Como gerar e instalar o APK

### Usando apenas o navegador do celular (compilação na nuvem)

1. Crie um repositório GitHub com README para inicializar a branch principal. Se escolher público, o código ficará visível e os minutos do runner padrão são gratuitos; armazenamento de artefatos tem limites do plano.
2. Envie o arquivo `EntregaClara-Android.zip` inteiro para a raiz do repositório, sem descompactar ou renomear.
3. Pelo botão Add file > Create new file, crie `.github/workflows/gerar-apk.yml` e cole o conteúdo do arquivo `gerar-apk.yml` incluído neste pacote. Salve na branch principal.
4. Vá a Actions > Gerar APK > Run workflow. No celular, pode ser necessário ativar Site para computador no navegador.
5. Se terminar com sucesso, abra a execução e baixe `EntregaClara-APK` na seção Artifacts, estando conectado ao GitHub. Extraia o ZIP baixado para obter `app-debug.apk`.
6. Instale para testar. A configuração compila um APK debug, sem chave privada de publicação. Cada execução pode gerar uma chave debug diferente, o que pode exigir desinstalar a versão anterior para instalar a nova; desinstalar apaga os dados locais.

Esta automação foi preparada, mas não executada no GitHub neste ambiente. Se falhar, abra o passo vermelho da execução e compartilhe a mensagem de erro. Ela aceita as licenças do Android SDK durante a preparação. O APK ficará disponível por 3 dias, sujeito aos limites de armazenamento da conta.

### Usando um computador

1. Em um computador, instale Android Studio com JDK 17, Android SDK Platform 35 e acesso aos repositórios Google/Maven Central.
2. Extraia o ZIP e abra a pasta `EntregaClara` como projeto no Android Studio.
3. Configure a distribuição do Gradle **8.11.1** em Settings > Build, Execution, Deployment > Build Tools > Gradle. O projeto usa Android Gradle Plugin 8.9.2. O Gradle Wrapper não está incluído; é possível gerá-lo com uma instalação local do Gradle: `gradle wrapper --gradle-version 8.11.1`.
4. Sincronize o projeto e execute **Build > Build App Bundle(s) / APK(s) > Build APK(s)**, ou `gradle :app:assembleDebug` com Gradle local configurado.
5. O APK de desenvolvimento será gerado em `app/build/outputs/apk/debug/app-debug.apk`. Transfira para seu celular ou instale por USB com Android Studio. O dispositivo precisa ter Android 9 ou superior.
6. A versão debug serve para testes pessoais. Publicação exige compilação de release assinada, validação em aparelhos e atendimento às políticas atuais da loja, inclusive declaração de uso de acessibilidade.

## Configuração no celular

1. Abra o Entrega Clara e leia o aviso de acesso às telas.
2. Se concordar, selecione **apenas os aplicativos de entregador** da Keeta, 99Food e iFood efetivamente instalados. A escolha usa o nome e o identificador reais do aparelho, sem presumir os pacotes. Não selecione apps de consumidor.
3. Abra as configurações de acessibilidade do Android e habilite o serviço Entrega Clara. Dependendo da versão do Android e da origem da instalação, o sistema pode exigir autorização adicional; siga as orientações oficiais do próprio aparelho.
4. Ligue a análise automática na tela inicial. Configure custo por km, limites e meta.
5. Abra um dos apps selecionados. Se uma oferta for reconhecida, o cartão aparece por até 10 segundos. Toque nele para fechar. Desligue a análise na tela inicial para pausar.
6. Use a calculadora manual quando não houver leitura. Registrar uma entrega como concluída exige confirmação adicional. Não há detecção automática de aceite, conclusão ou pagamento.

## Limites da leitura automática

O adaptador genérico só reconhece telas com indicação textual de oferta/aceite, exatamente um preço com `R$` e exatamente uma distância com `km`. Não soma trechos, não usa OCR, não lê imagens e não acessa APIs privadas dos serviços. Valores repetidos também causam rejeição. Ofertas com mais de um preço/distância são ignoradas para evitar escolher o número errado. Tempo ausente ou ambíguo não é estimado.

Mesmo uma tela com um único km pode mostrar apenas um trecho: **confira se a distância inclui coleta e entrega**. Os dados podem estar indisponíveis à acessibilidade. O cartão pode ocultar parte da interface e pode ser fechado com toque. Mudanças de layout podem interromper a leitura. Algumas telas podem conter palavras de oferta e gerar falso positivo; o resultado é auxiliar e experimental.

O histórico automático reduz repetições iguais por aplicativo/valor/km por 60 segundos, mas não identifica pedidos. Pode agrupar ofertas iguais ou registrar uma oferta novamente após esse intervalo. Nenhuma oferta analisada é contada como ganho. A contagem de meta usa a data local do aparelho e mantém no máximo 200 entregas registradas. Não possui edição individual de lançamentos nesta versão; a exclusão disponível apaga todos os dados.

Para adaptar aos apps reais, são necessárias capturas anonimizadas de ofertas de cada serviço, incluindo exemplos com coleta e entrega separadas, e testes no modelo/Android do usuário. Não envie dados de clientes, endereços completos, telefone ou identificadores do pedido.

## Privacidade

Não solicita permissão de internet, localização, câmera, microfone ou armazenamento compartilhado. Não usa SDKs de terceiros. O serviço recebe eventos de janela do Android e só consulta o conteúdo da janela ativa quando seu pacote está na lista explicitamente selecionada e a análise está ligada com consentimento. Textos são processados em memória; só aplicativo, horário, preço, km e custo estimado são salvos nas preferências privadas. Backup do Android desabilitado. Apagar os dados também limpa consentimento e desliga a análise.

## Verificações

Na raiz do projeto, com JDK 17:

```sh
java checks/Verify.java
```

Isso compila o parser real e executa 15 verificações de reconhecimento, rejeição de ambiguidades e cálculo. Não verifica o ciclo de vida ou a interface Android.

Antes de utilizar em trabalho real, validar no aparelho:

- Primeiro acesso sem consentimento: leitura desativada.
- Ativar/pausar, trocar app selecionado e revogar o serviço: cartão deve sumir.
- Demonstrar oferta fictícia e comparar manualmente as fórmulas.
- Sem acesso à internet: calculadora e histórico devem funcionar.
- Tela sem oferta, saldo, múltiplas distâncias ou valores: não exibir resultado.
- Conferir ofertas reais dos três apps e o significado dos quilômetros.
- Reiniciar o aparelho, alternar apps, bloquear/desbloquear a tela e verificar consumo/bateria.
- Entrega analisada não entra na meta; confirmação manual entra uma vez por lançamento.

Referências de implementação: documentação oficial do Android para AccessibilityService e configuração de serviços de acessibilidade: https://developer.android.com/reference/android/accessibilityservice/AccessibilityService e https://developer.android.com/guide/topics/ui/accessibility/service.
