import java.nio.file.*;
import java.net.*;
import javax.tools.*;
public class Verify {
    public static void main(String[] args) throws Exception {
        Path out=Files.createTempDirectory("entregaclara-check-");
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("Use um JDK 17 completo.");
        int result=compiler.run(null,null,null,"-d",out.toString(),"app/src/main/java/br/com/entregaclara/OfferParser.java","checks/ParserChecks.java");
        if(result!=0)throw new IllegalStateException("Falha de compilação do parser.");
        try(URLClassLoader loader=new URLClassLoader(new URL[]{out.toUri().toURL()})){
            loader.loadClass("ParserChecks").getMethod("main",String[].class).invoke(null,(Object)new String[0]);
        }
    }
}
