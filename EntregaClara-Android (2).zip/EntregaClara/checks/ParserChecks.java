import br.com.entregaclara.OfferParser;

public final class ParserChecks {
    private static int count;
    static void check(boolean ok,String message){count++;if(!ok)throw new AssertionError(message);}
    public static void main(String[] args) {
        OfferParser.Offer o=OfferParser.parse("Nova entrega\nR$ 12,00\n4,0 km\n20 min\nAceitar");
        check(o!=null,"Oferta simples reconhecida");
        check(o.perKm()==3,"R$/km correto");
        check(Math.abs(o.net(0.35)-10.6)<0.00001,"Custo descontado");
        check(o.minutes==20,"Tempo explícito");
        check(OfferParser.parse("Saldo R$ 12,00 4 km")==null,"Saldo não vira oferta");
        check(OfferParser.parse("Aceitar R$ 12,00 R$ 2,00 4 km")==null,"Valores ambíguos rejeitados");
        check(OfferParser.parse("Aceitar R$ 12,00 1 km 3 km")==null,"Distâncias por trecho rejeitadas");
        check(OfferParser.parse("Aceitar R$ 12,00 0 km")==null,"Distância zero rejeitada");
        check(OfferParser.parse("Aceitar R$ 0,00 4 km")==null,"Valor zero rejeitado");
        check(OfferParser.parse("Aceitar R$ 12,00 800 m")==null,"Metros não interpretados como km");
        check(OfferParser.parse("Aceitar R$ 12,00 4 km").minutes==null,"Tempo ausente não é inventado");
        check(OfferParser.parse("Aceitar R$ 12,00 4 km 5 min 20 min").minutes==null,"Tempos ambíguos ignorados");
        check(OfferParser.parse("ACEITAR R$ 9.50 2.5 KM")!=null,"Separador ponto e maiúsculas");
        check(OfferParser.parse(null)==null,"Entrada nula");
        check(OfferParser.parse("Aceitar R$ 1.234,56 4 km")==null,"Milhar não suportado não gera valor parcial");
        System.out.println(count+" verificações do parser e cálculo passaram.");
    }
}
